A template for 200x300 map with 30 border.
Lines to help build a symmetrical map.

Made By:
Tango4Bravo
(tango4bravo@gmail.com)