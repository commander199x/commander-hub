Balanced 1v1 map in a dessert / oasis environment. Plenty of supplies to get started and option for 2 oil grabs close to each base. Additional supplies in the middle and right, and lastly an oil refinary on the left.

Working AI for testing and figuring out the map - but made for online 1v1s.

Map by ViTeXFTW
Youtube: ViTeXFTW
Discord: ViTeXFTW