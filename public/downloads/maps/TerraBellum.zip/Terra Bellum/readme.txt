Terra Bellum

Author: GB

Map Size: 350 x 600

# Players: 3


The morning sun is flooding over this urban landscape and displaces the moisture and chill of the night. The new day begins and the city comes to life once again. Terra Bellum is a detailed design map which provides everything for challenging combats.
