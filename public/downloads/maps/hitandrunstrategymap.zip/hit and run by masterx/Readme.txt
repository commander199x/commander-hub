This is a Hit&Run Strategy map, basically you need to kill as many of your enemies as possible with the lowest casualty possible
basically you start with a built in base, and you get 1 sniper with the ability to destroy structures
and a worker in which is able to build turret bunkers that contain a built in turrets
those 2 units are considered a special units and marked on the map with a white dot, if they're killed they will not respawn
as for the other units, you get 50 troops of gla rebels, if killed they will respawn back for indefenitely
those units has a button option to suicide, this option is helpful to let units suicide so that you can deny your opponent from having major kills when you're at a bad spot, 
each time you kill 100 units of your opponent, the map will reward you with a level up upgrade, basically that new level will replace your rebels with better units, and the cycle goes on to a total of 20 levels

Created by MasterX
Email sofyan_light@hotmail.com