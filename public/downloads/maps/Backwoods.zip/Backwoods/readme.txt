Backwoods

Author: GB

Map Size: 400 x 400

# Players: 4


The morning sun is flooding over this rolling countryside and driving out the chill of the night. The centrally located military camp and additional tactically placed camps and buildings provide everything for exciting fights. 