-- Run this in Supabase SQL Editor

alter table profiles add column is_team boolean default false not null;

-- Optional: mark yourself as team right away (replace with your username)
update profiles set is_team = true where username = 'Commander';
