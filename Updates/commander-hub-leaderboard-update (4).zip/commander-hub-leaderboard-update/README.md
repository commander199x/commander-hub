# Leaderboard Update — Where Each File Goes

Copy these into your `commander-hub` project, matching the paths below.
These REPLACE the existing files at the same path (back them up first if unsure).

1. `sql/matches_table.sql`
   → Run this in the Supabase SQL editor (not a project file — just paste and run).

2. `components/MatchForm.tsx`
   → Copy into `commander-hub/components/MatchForm.tsx` (new file)

3. `app/leaderboard/page.tsx`
   → Replaces `commander-hub/app/leaderboard/page.tsx`

4. `app/admin/page.tsx`
   → Replaces `commander-hub/app/admin/page.tsx`
   → This version wires in the new MatchForm at the top of the panel.

## NOT included in this zip (do these manually)

- The one-line NAV fix in `components/Header.tsx` (add the LEADERBOARD entry) —
  you already applied this yourself.
- Deleting the orphaned duplicate `Header.tsx` at the project root — still
  needs manual review since it has the OWNER badge feature the real one doesn't.

## After copying files in

```
git add .
git commit -m "Add match logging + tabbed leaderboard (4v4/FFA)"
git push
```

Then confirm the Supabase SQL ran successfully before testing the new
"Log a Match" form on /admin.
