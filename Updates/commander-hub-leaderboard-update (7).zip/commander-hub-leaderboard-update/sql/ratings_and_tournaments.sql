-- Run this AFTER matches_table.sql has already been applied.
-- Safe to run even if some of these already exist (uses IF NOT EXISTS where possible).

-- 1. Add a rating column to profiles (ELO-style, default 1000)
alter table profiles add column if not exists rating integer not null default 1000;

-- 2. Add optional tournament tagging + rating-change tracking to matches
alter table matches add column if not exists tournament_name text;
alter table matches add column if not exists round text;
alter table matches add column if not exists rating_changes jsonb;

-- 3. (Reminder) If you haven't already added 3v3 as a valid mode, run:
--   alter table matches drop constraint matches_mode_check;
--   alter table matches add constraint matches_mode_check check (mode in ('3v3', '4v4', 'ffa'));
