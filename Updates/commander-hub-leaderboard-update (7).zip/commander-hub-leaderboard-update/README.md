# Commander Hub — Leaderboard System (Full Update)

## Where each file goes

Copy into `commander-hub`, matching these paths exactly. These REPLACE
existing files at the same path.

1. `sql/matches_table.sql` — run in Supabase SQL editor (matches table + RLS).
   If you already ran an earlier version, use the `alter table` snippet in
   the comments at the top instead of the `create table` block.

2. `sql/ratings_and_tournaments.sql` — run AFTER matches_table.sql.
   Adds: `profiles.rating` column, `matches.tournament_name`,
   `matches.round`, `matches.rating_changes` columns.

3. `lib/elo.ts` — new file. Basic ELO rating calculator used by MatchForm.

4. `components/MatchForm.tsx` — replaces existing file.
   Now includes: team-based picker (3v3/4v4) + FFA picker, team size cap,
   optional Tournament name / Round fields, and automatic ELO rating
   updates on submit.

5. `app/leaderboard/page.tsx` — replaces existing file.
   Now includes: mode tabs (3v3/4v4/FFA), avatars, Rating column, crown
   icon for #1, 🔥 win-streak indicator (3+ streak), search box, date
   range filter (all-time/month/week), sort toggle (wins/win%/rating/
   matches played), styled match history with winner/loser boxes,
   rating change (+/-) shown per match, and an admin-only Delete button
   on each match row.

6. `app/admin/page.tsx` — replaces existing file. Wires MatchForm into
   the admin panel (same as before, unchanged from earlier update).

7. `components/PlayerMatchHistory.tsx` — NEW component, not yet wired
   into anything. To show a player's match history on their profile
   page, open your `app/profile/[username]/page.tsx` and add:

   ```tsx
   import PlayerMatchHistory from "@/components/PlayerMatchHistory";
   // ...inside the component, wherever you want it to appear:
   <PlayerMatchHistory username={profile.username} />
   ```

   This wasn't wired in automatically because your profile page file
   wasn't shared in this session — dropping it in blind risked breaking
   something else on that page.

8. `app/tournaments/standings/page.tsx` — NEW page at
   `/tournaments/standings`. Shows a dropdown of tournament names (taken
   from whatever you type into the "Tournament name" field when logging
   a match) and displays standings + matches grouped by round for the
   selected tournament.

   NOTE: this is a lightweight standings viewer, NOT a full bracket
   system. It doesn't auto-generate brackets or advance winners to next
   rounds automatically — it just groups matches you've already logged
   by the tournament name/round text you typed in. A real bracket
   system (auto-seeding, auto-advancing winners) is a bigger feature
   that needs its own dedicated design pass.

## What's new in this update vs the previous one

- ELO-style rating system (starts at 1000, adjusts after every match)
- Win/loss streak tracking with a 🔥 badge at 3+ wins in a row
- Crown icon for the #1 ranked player per mode
- Search box to filter the leaderboard by username
- Date range filter (all-time / this month / this week)
- Sort toggle (wins / win % / rating / matches played)
- Admin-only delete button on match history rows
- Optional tournament name + round tagging when logging a match
- New /tournaments/standings page to view tagged tournament results
- New PlayerMatchHistory component for profile pages (not yet wired in)

## Known simplifications (documented, not bugs)

- ELO for team matches uses each team's AVERAGE rating to compute one
  shared delta applied to every player on that team equally — it doesn't
  weight individual skill within a team.
- ELO for FFA matches compares the winner against each loser 1-on-1 and
  averages the winner's deltas — it doesn't account for losers' matchups
  against each other.
- Tournament standings are manual: you type a tournament name/round when
  logging each match. There's no bracket generator or auto-advancement.

## After copying files in

```
git add .
git commit -m "Full leaderboard system: ratings, streaks, search, tournaments"
git push
```

Then run BOTH SQL files (matches_table.sql if not already run, then
ratings_and_tournaments.sql) on your PRODUCTION Supabase project before
testing on commander.host.
