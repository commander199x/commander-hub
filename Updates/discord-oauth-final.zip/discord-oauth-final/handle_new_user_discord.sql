-- Updated version of your existing handle_new_user trigger function.
-- Email/password signups behave EXACTLY as before (uses raw_user_meta_data->>'username').
-- Discord OAuth signups (which have no manually-typed username) fall back to
-- Discord's own username field, sanitized to your existing format rules,
-- with collision handling in case two people share a Discord username.

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
as $$
declare
  base_username text;
  final_username text;
  attempt int := 0;
begin
  -- 1. Prefer the explicit username from email/password signup (unchanged).
  base_username := new.raw_user_meta_data->>'username';

  -- 2. Fall back to Discord's username field for OAuth signups.
  if base_username is null or base_username = '' then
    base_username := new.raw_user_meta_data->>'user_name';
  end if;

  -- 3. Last resort: generate something from the user id.
  if base_username is null or base_username = '' then
    base_username := 'user_' || substr(new.id::text, 1, 8);
  end if;

  -- Sanitize to match your existing format rule (letters/numbers/underscore only).
  base_username := regexp_replace(base_username, '[^a-zA-Z0-9_]', '', 'g');
  if base_username = '' then
    base_username := 'user_' || substr(new.id::text, 1, 8);
  end if;

  final_username := base_username;

  -- Handle username collisions (e.g. two Discord users with the same name)
  -- by appending a random 4-digit suffix and retrying a few times.
  loop
    begin
      insert into public.profiles (id, username, avatar_url)
      values (new.id, final_username, new.raw_user_meta_data->>'avatar_url');
      exit;
    exception when unique_violation then
      attempt := attempt + 1;
      final_username := base_username || floor(random() * 9000 + 1000)::int::text;
      if attempt > 5 then
        raise exception 'Could not generate a unique username after several attempts';
      end if;
    end;
  end loop;

  return new;
end;
$$;
