"use client";

import { ArrowUpRight, Play, Radio } from "lucide-react";
import { C, DISCORD_URL, YOUTUBE_URL } from "@/lib/theme";
import { useLanguage } from "@/lib/i18n/LanguageContext";
import RadarScope from "./RadarScope";
import { HOME_TEXT } from "./homeText";
import type { HomeData } from "./useHomeData";
import "@/app/cinematic.css";

const GRID = "linear-gradient(rgba(39,43,30,0.55) 1px, transparent 1px), linear-gradient(90deg, rgba(39,43,30,0.55) 1px, transparent 1px)";

export default function CinematicHero({ data }: { data: HomeData }) {
  const { locale } = useLanguage();
  const text = HOME_TEXT[locale === "ar" ? "ar" : "en"];
  const rtl = locale === "ar";

  const leaders = data.teamTop.map((l) => ({ name: l.name, rating: l.rating }));

  // Only show a stat once it has something to show — "0 matches" would hurt more than it helps.
  const stats = [
    { value: data.members, label: text.statPlayers },
    { value: data.matches, label: text.statMatches },
    { value: data.replays, label: text.statReplays },
  ].filter((s) => s.value > 0);

  const barStyle = {
    background: "#000",
    color: C.muted,
    fontSize: 10,
    letterSpacing: "0.22em",
    textTransform: "uppercase" as const,
  };

  return (
    <section
      className="relative overflow-hidden"
      style={{
        backgroundColor: C.void,
        backgroundImage: `radial-gradient(ellipse 60% 70% at ${rtl ? "22%" : "78%"} 45%, rgba(143,191,79,0.13), transparent 62%), radial-gradient(ellipse 50% 50% at ${rtl ? "10%" : "90%"} 10%, rgba(232,166,61,0.14), transparent 60%), ${GRID}`,
        backgroundSize: "100% 100%, 100% 100%, 56px 56px, 56px 56px",
      }}
    >
      {/* Radar — large and cropped on desktop, in the flow on phones */}
      <div
        className="pointer-events-none absolute hidden md:block"
        style={{ insetInlineEnd: "-12%", top: 92, width: "min(58vw, 840px)", zIndex: 1 }}
      >
        <RadarScope uid="hero" leaders={leaders} />
      </div>

      {/* Keeps the text readable over the radar */}
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{
          zIndex: 1,
          background: `linear-gradient(${rtl ? "270deg" : "90deg"}, ${C.void} 0%, rgba(10,12,8,0.88) 38%, rgba(10,12,8,0) 70%), linear-gradient(0deg, ${C.void} 0%, rgba(10,12,8,0) 30%)`,
        }}
      />

      {/* Cinematic letterbox bars */}
      <div className="absolute inset-x-0 top-0 flex h-[38px] items-center justify-between px-6 md:px-16" style={{ ...barStyle, zIndex: 3 }}>
        <span>{text.barLeft}</span>
        <span className="inline-flex items-center gap-2">
          <span className="cz-blink inline-block h-1.5 w-1.5 rounded-full" style={{ background: C.radar }} />
          {text.barRight}
        </span>
      </div>
      <div className="absolute inset-x-0 bottom-0 flex h-[38px] items-center justify-between px-6 md:px-16" style={{ ...barStyle, zIndex: 3 }}>
        <span>{text.barScroll}</span>
        <span>{text.barLangs}</span>
      </div>

      <div className="relative mx-auto max-w-[1312px] px-6 pb-24 pt-[64px] md:px-16 md:pt-[120px]" style={{ zIndex: 2, minHeight: 760 }}>
        <div className="mx-auto mb-2 mt-2 w-[300px] md:hidden" style={{ pointerEvents: "none" }}>
          <RadarScope uid="hero-m" leaders={leaders} decorative />
        </div>

        <div className="cz-rise cz-d1 flex items-center gap-2.5 text-xs uppercase tracking-[0.24em]" style={{ color: C.radar }}>
          <Radio size={14} />
          <span>{text.heroEyebrow}</span>
        </div>

        <h1
          className="cz-display mt-5 uppercase"
          style={{ fontSize: "clamp(84px, 13vw, 180px)", lineHeight: 0.86, fontWeight: 700, color: C.paper }}
        >
          <span className="cz-rise cz-d2 block">{text.heroLine1}</span>
          <span className="cz-rise cz-d3 block" style={{ color: C.amber }}>
            {text.heroLine2}
          </span>
        </h1>

        <p className="cz-rise cz-d4 mt-7 max-w-[500px] text-base leading-relaxed md:text-lg" style={{ color: C.paper }}>
          {text.heroSub}
        </p>

        <div className="cz-rise cz-d5 mt-8 flex flex-wrap items-center gap-x-7 gap-y-3">
          <a
            href={DISCORD_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-[58px] items-center gap-2.5 px-8 text-sm font-bold uppercase tracking-[0.12em]"
            style={{ background: C.amber, color: C.void, boxShadow: "0 0 34px rgba(232,166,61,0.32)" }}
          >
            {text.joinClan}
            <ArrowUpRight size={16} strokeWidth={2.5} />
          </a>
          <a
            href={YOUTUBE_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-[44px] items-center gap-3 text-[13px] font-semibold uppercase tracking-[0.1em]"
            style={{ color: C.paper }}
          >
            <span className="inline-flex h-[38px] w-[38px] items-center justify-center rounded-full" style={{ background: "#CC0000" }}>
              <Play size={14} color="#fff" fill="#fff" />
            </span>
            {text.watchLatest}
          </a>
        </div>

        {stats.length > 0 && (
          <div
            className="cz-rise cz-d5 mt-14 flex max-w-[700px] flex-wrap gap-x-0 gap-y-4 pt-6 md:mt-20"
            style={{ borderTop: `1px solid ${C.lineStrong}` }}
          >
            {stats.map((s) => (
              <div key={s.label} className="flex-1" style={{ minWidth: 110, paddingInlineEnd: 24 }}>
                <div className="cz-display" style={{ fontSize: "clamp(40px, 5vw, 60px)", fontWeight: 700, lineHeight: 1, color: C.amber }}>
                  {s.value.toLocaleString("en")}
                </div>
                <div className="mt-2 text-[11px] uppercase tracking-[0.18em]" style={{ color: C.muted }}>
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
