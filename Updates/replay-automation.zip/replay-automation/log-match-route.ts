import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { computeTeamMatchDeltas, computeFfaMatchDeltas, DEFAULT_RATING } from "@/lib/elo";

// This route lets a trusted local script (e.g. the replay watcher) log a
// match without going through the browser admin form. It's protected by
// a shared secret, NOT by Supabase user auth, since the script runs on
// your own PC with no browser session.
//
// Required env vars (add to .env.local, NEVER commit or expose publicly):
//   REPLAY_UPLOAD_SECRET=<a long random string you make up>
//   SUPABASE_SERVICE_ROLE_KEY=<from Supabase project settings > API>
//
// The service role key bypasses RLS, so this route must ALWAYS check the
// secret before touching the database.

function getAdminClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
}

function ratingColumnFor(mode: string): "rating_team" | "rating_ffa" {
  return mode === "ffa" ? "rating_ffa" : "rating_team";
}

export async function POST(req: NextRequest) {
  const secret = req.headers.get("x-replay-secret");
  if (!secret || secret !== process.env.REPLAY_UPLOAD_SECRET) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await req.json();
  const { mode, participants, winners, notes, matchDate } = body as {
    mode: "2v2" | "3v3" | "4v4" | "ffa";
    participants: string[];
    winners: string[];
    notes?: string;
    matchDate?: string; // YYYY-MM-DD, optional
  };

  if (!mode || !participants?.length || !winners?.length) {
    return NextResponse.json({ error: "Missing mode, participants, or winners" }, { status: 400 });
  }

  const supabase = getAdminClient();
  const column = ratingColumnFor(mode);
  const losers = participants.filter((p) => !winners.includes(p));

  // Fetch current ratings (registered profiles + guests) to compute deltas.
  const { data: profileRows } = await supabase
    .from("profiles")
    .select(`username, ${column}`)
    .in("username", participants);

  const registeredSet = new Set((profileRows ?? []).map((p: any) => p.username));
  const guestNames = participants.filter((p) => !registeredSet.has(p));

  const { data: guestRows } =
    guestNames.length > 0
      ? await supabase.from("guest_ratings").select(`name, ${column}`).in("name", guestNames)
      : { data: [] };

  const currentRatings: Record<string, number> = {};
  for (const p of (profileRows ?? []) as any[]) currentRatings[p.username] = p[column] ?? DEFAULT_RATING;
  for (const g of (guestRows ?? []) as any[]) currentRatings[g.name] = g[column] ?? DEFAULT_RATING;

  const isTeamMode = mode === "2v2" || mode === "3v3" || mode === "4v4";
  const deltas = isTeamMode
    ? computeTeamMatchDeltas(currentRatings, winners, losers)
    : computeFfaMatchDeltas(currentRatings, winners[0], losers);

  const created_at = matchDate ? new Date(`${matchDate}T12:00:00`).toISOString() : new Date().toISOString();

  const { error: insertError } = await supabase.from("matches").insert({
    mode,
    participants,
    winners,
    notes: notes || "Logged automatically from replay file",
    rating_changes: deltas,
    created_at,
  });

  if (insertError) {
    return NextResponse.json({ error: insertError.message }, { status: 500 });
  }

  // Apply the rating changes.
  for (const username of Object.keys(deltas)) {
    const newRating = (currentRatings[username] ?? DEFAULT_RATING) + deltas[username];
    if (registeredSet.has(username)) {
      await supabase.from("profiles").update({ [column]: newRating }).eq("username", username);
    } else {
      await supabase.from("guest_ratings").upsert({ name: username, [column]: newRating }, { onConflict: "name" });
    }
  }

  return NextResponse.json({ success: true, deltas });
}
