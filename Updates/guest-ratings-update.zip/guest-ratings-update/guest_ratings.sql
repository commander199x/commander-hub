-- Persists ratings for guest players (no site account) so their rating
-- actually updates over time instead of always showing the 1000 default.

create table if not exists guest_ratings (
  name text primary key,
  rating_team integer not null default 1000,
  rating_ffa integer not null default 1000
);

alter table guest_ratings enable row level security;

create policy "Anyone can view guest ratings"
  on guest_ratings for select
  using (true);

create policy "Admins can insert guest ratings"
  on guest_ratings for insert
  with check (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and (profiles.is_admin = true or profiles.is_owner = true)
    )
  );

create policy "Admins can update guest ratings"
  on guest_ratings for update
  using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and (profiles.is_admin = true or profiles.is_owner = true)
    )
  );
