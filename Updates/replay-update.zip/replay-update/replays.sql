-- Run AFTER matches_table.sql and ratings_and_tournaments.sql.

-- 1. Add a column to store either a pasted link OR the URL of an uploaded file.
alter table matches add column if not exists replay_url text;

-- 2. Create a public storage bucket for uploaded .rep files.
-- (If this errors saying the bucket already exists, that's fine — skip it.)
insert into storage.buckets (id, name, public)
values ('replays', 'replays', true)
on conflict (id) do nothing;

-- 3. Anyone can view/download replay files (bucket is public).
create policy "Anyone can view replays"
  on storage.objects for select
  using (bucket_id = 'replays');

-- 4. Only admins/owners can upload replay files.
create policy "Admins can upload replays"
  on storage.objects for insert
  with check (
    bucket_id = 'replays'
    and exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and (profiles.is_admin = true or profiles.is_owner = true)
    )
  );

-- 5. Only admins/owners can delete replay files (for cleanup).
create policy "Admins can delete replays"
  on storage.objects for delete
  using (
    bucket_id = 'replays'
    and exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and (profiles.is_admin = true or profiles.is_owner = true)
    )
  );
