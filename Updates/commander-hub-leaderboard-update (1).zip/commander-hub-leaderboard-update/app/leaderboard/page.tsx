"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import "@/app/leaderboard.css";

type Match = {
  id: string;
  mode: "3v3" | "4v4" | "ffa";
  participants: string[];
  winners: string[];
  notes: string | null;
  created_at: string;
};

type StatRow = { username: string; wins: number; losses: number };

export default function LeaderboardPage() {
  const supabase = createClient();
  const [mode, setMode] = useState<"3v3" | "4v4" | "ffa">("4v4");
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const { data } = await supabase
        .from("matches")
        .select("*")
        .order("created_at", { ascending: false });
      setMatches(data ?? []);
      setLoading(false);
    }
    load();
  }, [supabase]);

  const filtered = matches.filter((m) => m.mode === mode);

  const stats = new Map<string, StatRow>();
  for (const m of filtered) {
    for (const username of m.participants) {
      const row = stats.get(username) ?? { username, wins: 0, losses: 0 };
      if (m.winners.includes(username)) row.wins += 1;
      else row.losses += 1;
      stats.set(username, row);
    }
  }

  const ranked = Array.from(stats.values()).sort((a, b) => b.wins - a.wins);

  return (
    <main className="leaderboard-page">
      <div className="leaderboard-container">
        <h1>Leaderboard</h1>

        <div style={{ display: "flex", gap: "1rem", marginBottom: "1rem" }}>
          <button onClick={() => setMode("3v3")} style={{ fontWeight: mode === "3v3" ? 700 : 400 }}>
            3v3
          </button>
          <button onClick={() => setMode("4v4")} style={{ fontWeight: mode === "4v4" ? 700 : 400 }}>
            4v4
          </button>
          <button onClick={() => setMode("ffa")} style={{ fontWeight: mode === "ffa" ? 700 : 400 }}>
            FFA
          </button>
        </div>

        {loading ? (
          <p>Loading...</p>
        ) : (
          <>
            <div className="leaderboard-table">
              <div className="leaderboard-row leaderboard-header-row">
                <span className="lb-rank">#</span>
                <span className="lb-player">Player</span>
                <span className="lb-stat">W</span>
                <span className="lb-stat">L</span>
                <span className="lb-stat">Win %</span>
              </div>

              {ranked.map((p, i) => {
                const total = p.wins + p.losses;
                const winRate = total > 0 ? Math.round((p.wins / total) * 100) : 0;
                return (
                  <Link key={p.username} href={`/profile/${p.username}`} className="leaderboard-row">
                    <span className="lb-rank">{i + 1}</span>
                    <span className="lb-player">{p.username}</span>
                    <span className="lb-stat lb-wins">{p.wins}</span>
                    <span className="lb-stat lb-losses">{p.losses}</span>
                    <span className="lb-stat">{winRate}%</span>
                  </Link>
                );
              })}

              {ranked.length === 0 && (
                <p className="leaderboard-empty">No {mode.toUpperCase()} matches logged yet.</p>
              )}
            </div>

            <h2 style={{ marginTop: "2rem" }}>Recent Matches</h2>
            <div className="leaderboard-table">
              {filtered.slice(0, 15).map((m) => (
                <div key={m.id} className="leaderboard-row">
                  <span>{new Date(m.created_at).toLocaleDateString()}</span>
                  <span>Winner{m.winners.length > 1 ? "s" : ""}: {m.winners.join(", ")}</span>
                  <span style={{ opacity: 0.6 }}>
                    vs {m.participants.filter((p) => !m.winners.includes(p)).join(", ")}
                  </span>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </main>
  );
}
