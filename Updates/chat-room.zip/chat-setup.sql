-- Run this in Supabase SQL Editor

create table messages (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users on delete cascade not null,
  username text not null,
  content text not null,
  created_at timestamp with time zone default now()
);

alter table messages enable row level security;

create policy "Anyone can read messages"
  on messages for select using (true);

create policy "Logged-in users can post their own messages"
  on messages for insert
  with check (auth.uid() = user_id);

-- Enable realtime updates for this table
alter publication supabase_realtime add table messages;
