-- Run this in Supabase SQL Editor

alter table profiles add column is_owner boolean default false not null;

-- Set yourself as owner (replace with your actual username)
update profiles set is_owner = true where username = 'Commander';
