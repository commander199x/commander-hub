"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

type Profile = { username: string };

export default function MatchForm({ allUsers }: { allUsers: Profile[] }) {
  const supabase = createClient();
  const [mode, setMode] = useState<"4v4" | "ffa">("4v4");
  const [participants, setParticipants] = useState<string[]>([]);
  const [winners, setWinners] = useState<string[]>([]);
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  function toggleParticipant(username: string) {
    setParticipants((prev) =>
      prev.includes(username) ? prev.filter((u) => u !== username) : [...prev, username]
    );
    setWinners((prev) => prev.filter((u) => u !== username || participants.includes(username)));
  }

  function toggleWinner(username: string) {
    if (mode === "ffa") {
      setWinners([username]);
      return;
    }
    setWinners((prev) =>
      prev.includes(username) ? prev.filter((u) => u !== username) : [...prev, username]
    );
  }

  async function handleSubmit() {
    setMessage(null);

    if (participants.length === 0) {
      setMessage("Select at least one participant.");
      return;
    }
    if (winners.length === 0) {
      setMessage("Select the winner(s).");
      return;
    }
    if (!winners.every((w) => participants.includes(w))) {
      setMessage("Winners must be part of the participants list.");
      return;
    }

    setSubmitting(true);
    const { error } = await supabase.from("matches").insert({
      mode,
      participants,
      winners,
      notes: notes || null,
    });
    setSubmitting(false);

    if (error) {
      setMessage(`Error: ${error.message}`);
    } else {
      setMessage("Match logged.");
      setParticipants([]);
      setWinners([]);
      setNotes("");
    }
  }

  return (
    <div style={{ border: "1px solid #333", padding: "1rem", marginBottom: "1rem" }}>
      <h3>Log a Match</h3>

      <div style={{ marginBottom: "0.75rem" }}>
        <label>Mode: </label>
        <select
          value={mode}
          onChange={(e) => {
            setMode(e.target.value as "4v4" | "ffa");
            setWinners([]);
          }}
        >
          <option value="4v4">4v4</option>
          <option value="ffa">FFA</option>
        </select>
      </div>

      <div style={{ marginBottom: "0.75rem" }}>
        <p>Participants:</p>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem" }}>
          {allUsers.map((u) => (
            <label key={u.username} style={{ fontSize: "0.85rem" }}>
              <input
                type="checkbox"
                checked={participants.includes(u.username)}
                onChange={() => toggleParticipant(u.username)}
              />{" "}
              {u.username}
            </label>
          ))}
        </div>
      </div>

      <div style={{ marginBottom: "0.75rem" }}>
        <p>Winner{mode === "4v4" ? "s (select the winning team)" : " (select one)"}:</p>
        <div style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem" }}>
          {participants.map((username) => (
            <label key={username} style={{ fontSize: "0.85rem" }}>
              <input
                type={mode === "ffa" ? "radio" : "checkbox"}
                name="winner"
                checked={winners.includes(username)}
                onChange={() => toggleWinner(username)}
              />{" "}
              {username}
            </label>
          ))}
          {participants.length === 0 && <p style={{ opacity: 0.6 }}>Select participants first.</p>}
        </div>
      </div>

      <textarea
        placeholder="Notes (optional)"
        value={notes}
        onChange={(e) => setNotes(e.target.value)}
        style={{ width: "100%", marginBottom: "0.75rem" }}
      />

      <button onClick={handleSubmit} disabled={submitting}>
        {submitting ? "Saving..." : "Log Match"}
      </button>

      {message && <p>{message}</p>}
    </div>
  );
}
