-- Run this in Supabase SQL editor

create table matches (
  id uuid primary key default gen_random_uuid(),
  mode text not null check (mode in ('4v4', 'ffa')),
  participants text[] not null,   -- all usernames who played
  winners text[] not null,        -- subset of participants who won
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

alter table matches enable row level security;

-- everyone can read match history
create policy "Anyone can view matches"
  on matches for select
  using (true);

-- only admins can insert
create policy "Admins can insert matches"
  on matches for insert
  with check (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and (profiles.is_admin = true or profiles.is_owner = true)
    )
  );

-- only admins can delete (for fixing mistakes)
create policy "Admins can delete matches"
  on matches for delete
  using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and (profiles.is_admin = true or profiles.is_owner = true)
    )
  );
