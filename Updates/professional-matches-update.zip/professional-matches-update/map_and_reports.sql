-- 1. Optional map name field on matches.
alter table matches add column if not exists map text;

-- 2. Table for players to report a suspicious/incorrect match for admin review.
create table if not exists match_reports (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references matches(id) on delete cascade,
  reported_by uuid references auth.users(id),
  reason text not null,
  created_at timestamptz not null default now()
);

alter table match_reports enable row level security;

-- Any logged-in user can report a match.
create policy "Logged in users can report matches"
  on match_reports for insert
  with check (auth.uid() is not null);

-- Only admins/owners can view reports.
create policy "Admins can view match reports"
  on match_reports for select
  using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and (profiles.is_admin = true or profiles.is_owner = true)
    )
  );

-- Only admins/owners can delete (dismiss) reports.
create policy "Admins can delete match reports"
  on match_reports for delete
  using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and (profiles.is_admin = true or profiles.is_owner = true)
    )
  );
