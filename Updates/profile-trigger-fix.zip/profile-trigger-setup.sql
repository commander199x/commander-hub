-- Run this in Supabase SQL Editor

-- This function runs with elevated privileges, so it can insert into
-- profiles even before the user has an active session (i.e. before
-- they've confirmed their email).
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, username)
  values (new.id, new.raw_user_meta_data->>'username');
  return new;
end;
$$;

-- Fires automatically whenever someone signs up
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
