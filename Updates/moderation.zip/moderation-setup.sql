-- Run this in Supabase SQL Editor

-- 1. Add moderation columns to profiles
alter table profiles add column is_admin boolean default false not null;
alter table profiles add column banned boolean default false not null;

-- 2. Make YOURSELF an admin (replace with your actual username)
update profiles set is_admin = true where username = 'Commander';

-- 3. Allow admins to delete any message
create policy "Admins can delete any message"
  on messages for delete
  using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and profiles.is_admin = true
    )
  );

-- 4. Block banned users from posting new messages
-- (drop and recreate the insert policy to add the ban check)
drop policy "Logged-in users can post their own messages" on messages;

create policy "Logged-in non-banned users can post messages"
  on messages for insert
  with check (
    auth.uid() = user_id
    and not exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and profiles.banned = true
    )
  );

-- 5. Allow admins to update any profile (needed to toggle bans from the UI)
create policy "Admins can update any profile"
  on profiles for update
  using (
    exists (
      select 1 from profiles p
      where p.id = auth.uid()
      and p.is_admin = true
    )
  );
