create table if not exists admin_audit_log (
  id uuid primary key default gen_random_uuid(),
  admin_username text not null,
  action text not null,
  details jsonb,
  created_at timestamptz not null default now()
);

alter table admin_audit_log enable row level security;

-- Only admins/owners can view the audit log.
create policy "Admins can view audit log"
  on admin_audit_log for select
  using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and (profiles.is_admin = true or profiles.is_owner = true)
    )
  );

-- Only admins/owners can write to it.
create policy "Admins can insert audit log entries"
  on admin_audit_log for insert
  with check (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and (profiles.is_admin = true or profiles.is_owner = true)
    )
  );
