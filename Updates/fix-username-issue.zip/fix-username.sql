-- Run this in Supabase SQL Editor
-- Replace 'oldusername' with the exact current value and 'newusername' with a clean one

update profiles
set username = 'newusername'
where username = 'COM|KASSEM';

-- Prevent this from happening again at the database level too
alter table profiles add constraint username_format_check
  check (username ~ '^[a-zA-Z0-9_]+$');
