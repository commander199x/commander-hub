"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import "@/app/auth.css";

export default function ForgotPasswordPage() {
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });

    setLoading(false);

    if (resetError) {
      setError(resetError.message);
      return;
    }

    setSubmitted(true);
  }

  if (submitted) {
    return (
      <main className="auth-page">
        <div className="auth-form">
          <h1>Check your email</h1>
          <p className="auth-switch" style={{ marginTop: 0 }}>
            If an account exists for <strong>{email}</strong>, we sent a
            password reset link. Click it to set a new password.
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="auth-page">
      <form onSubmit={handleSubmit} className="auth-form">
        <h1>Reset password</h1>
        <p className="auth-switch" style={{ marginTop: 0, marginBottom: "1rem" }}>
          Enter your email and we&apos;ll send you a reset link.
        </p>

        <label htmlFor="email">Email</label>
        <input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        {error && <p className="auth-error">{error}</p>}

        <button type="submit" disabled={loading}>
          {loading ? "Sending..." : "Send reset link"}
        </button>

        <p className="auth-switch">
          Remembered it? <a href="/login">Log in</a>
        </p>
      </form>
    </main>
  );
}
