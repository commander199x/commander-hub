-- Run this in Supabase SQL Editor

create table notifications (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users on delete cascade not null,
  message text not null,
  link text,
  read boolean default false not null,
  created_at timestamp with time zone default now()
);

alter table notifications enable row level security;

create policy "Users can view their own notifications"
  on notifications for select
  using (auth.uid() = user_id);

create policy "Users can update their own notifications"
  on notifications for update
  using (auth.uid() = user_id);

-- Admins can create notifications for anyone (e.g. announcements, ban notices)
create policy "Admins can insert notifications for any user"
  on notifications for insert
  with check (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and profiles.is_admin = true
    )
  );

alter publication supabase_realtime add table notifications;

-- Automatically notify a user when they get banned or unbanned
create or replace function public.notify_ban_status_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.banned is distinct from old.banned then
    insert into notifications (user_id, message)
    values (
      new.id,
      case when new.banned
        then 'You have been banned from chatting.'
        else 'Your chat ban has been lifted.'
      end
    );
  end if;
  return new;
end;
$$;

create trigger on_ban_status_change
  after update on profiles
  for each row execute function public.notify_ban_status_change();
