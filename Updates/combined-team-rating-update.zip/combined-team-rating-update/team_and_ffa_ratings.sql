-- Run this after per_mode_ratings.sql.
-- Consolidates 3v3 and 4v4 (and new 2v2) into ONE shared "team" rating,
-- while FFA stays completely separate.

-- 1. Allow '2v2' as a match mode.
alter table matches drop constraint matches_mode_check;
alter table matches add constraint matches_mode_check check (mode in ('2v2', '3v3', '4v4', 'ffa'));

-- 2. Add the new shared team rating column.
alter table profiles add column if not exists rating_team integer not null default 1000;

-- 3. Seed rating_team from whichever of the old per-mode columns has more
-- activity as a rough starting point. This is just a starting guess —
-- run "Recalculate All Ratings" on /admin afterward for the real, correct
-- numbers based on actual match history.
update profiles
set rating_team = coalesce(rating_4v4, rating_3v3, 1000)
where rating_team = 1000;

-- Note: rating_ffa (added in per_mode_ratings.sql) is unchanged and still
-- used as-is for FFA. The old rating_3v3 / rating_4v4 columns are no
-- longer used by the app after this update but are left in place
-- (harmless) rather than dropped.
