-- "Soft delete" safety net for matches.
-- Whenever ANY match row is deleted (admin button, SQL editor, anything),
-- a full copy is automatically saved into matches_trash first, so it can
-- be restored later from Admin -> Deleted matches (or via the Undo toast).

create table if not exists matches_trash (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null,
  data jsonb not null,                       -- the full original row
  deleted_at timestamptz not null default now(),
  deleted_by uuid                            -- auth user who deleted it (null if via SQL editor)
);

create index if not exists matches_trash_deleted_at_idx on matches_trash (deleted_at desc);
create index if not exists matches_trash_match_id_idx on matches_trash (match_id);

alter table matches_trash enable row level security;

drop policy if exists "Admins can view deleted matches" on matches_trash;
create policy "Admins can view deleted matches"
  on matches_trash for select
  using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and (profiles.is_admin = true or profiles.is_owner = true)
    )
  );

drop policy if exists "Admins can remove trash entries" on matches_trash;
create policy "Admins can remove trash entries"
  on matches_trash for delete
  using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
      and (profiles.is_admin = true or profiles.is_owner = true)
    )
  );

-- The trigger function runs with elevated rights so the copy is always
-- saved, even though regular users have no insert permission on the trash.
create or replace function public.archive_deleted_match()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.matches_trash (match_id, data, deleted_by)
  values (old.id, to_jsonb(old), auth.uid());
  return old;
end;
$$;

drop trigger if exists matches_archive_before_delete on matches;
create trigger matches_archive_before_delete
  before delete on matches
  for each row
  execute function public.archive_deleted_match();
