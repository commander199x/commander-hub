-- Run AFTER ratings_and_tournaments.sql has already added profiles.rating.
-- This splits that single shared rating into three separate per-mode ratings.

alter table profiles add column if not exists rating_3v3 integer not null default 1000;
alter table profiles add column if not exists rating_4v4 integer not null default 1000;
alter table profiles add column if not exists rating_ffa integer not null default 1000;

-- Optional: seed the new per-mode columns from the old shared 'rating'
-- column as a starting point (better than resetting everyone to 1000).
-- Skip this if you'd rather just run "Recalculate All Ratings" afterward,
-- which will compute correct per-mode values from match history anyway.
update profiles set rating_3v3 = rating, rating_4v4 = rating, rating_ffa = rating;

-- The old shared 'rating' column is no longer used by the app after this
-- update, but it's left in place (harmless) rather than dropped, in case
-- you want to keep it around for reference.
